clear;
load MovingStage6withAttSM2a.mat;
swap=@(varargin)varargin{nargin:-1:1};
x = 3
y = 17
[x,y] = swap(x,y)
TypeACohAlla=[];
[TypeACohAll, TypeACohAlla]=swap(TypeACohAll, TypeACohAlla);
